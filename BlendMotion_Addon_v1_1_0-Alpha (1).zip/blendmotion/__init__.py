# ═══════════════════════════════════════════════════════════════
#  BlendMotion — Real-time ARKit Camera Tracking for Blender
#  Version 1.0.0-Alpha
#  Copyright (C) 2026 Skettch
#
#  This program is free software: you can redistribute it and/or
#  modify it under the terms of the GNU General Public License as
#  published by the Free Software Foundation, either version 3 of
#  the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public
#  License along with this program. If not, see
#  <https://www.gnu.org/licenses/>.
#
#  This addon receives 6DoF camera tracking data from an iPhone
#  running the BlendMotion iOS app via UDP and applies it to
#  the active scene camera in real-time.
#
#  Security & Privacy:
#    - No telemetry, no analytics, no internet connection
#    - Local UDP only (LAN, never leaves your network)
#    - No data collection, no external servers
#    - No eval/exec, no file writes, no subprocess calls
#
#  Built with vibe coding methodology.
# ═══════════════════════════════════════════════════════════════

bl_info = {
    "name": "BlendMotion",
    "author": "Skettch",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > BlendMotion",
    "description": "Real-time ARKit camera tracking from iPhone (v1.0.0-Alpha)",
    "category": "Camera",
    "license": ["SPDX:GPL-3.0-or-later"],
    "doc_url": "https://blendermarket.com/products/blendmotion",
    "tracker_url": "https://blendermarket.com/products/blendmotion",
}

import bpy
import struct
import socket
import threading
import math
import time
from queue import Queue, Empty, Full
from mathutils import Matrix, Quaternion, Euler

# =====================================================
# Version
# =====================================================
BLENDMOTION_VERSION = "1.0.0-Alpha"

# =====================================================
# ARKit → Blender Coordinate Conversion
# =====================================================
# ARKit and Blender cameras share the SAME local convention:
#   x=right, y=up, -z=forward (both right-handed)
# Only the WORLD coordinate systems differ:
#   ARKit world:   X=right, Y=up,      Z=backward
#   Blender world: X=right, Y=forward, Z=up
#
# Conversion: Bx=Ax, By=-Az, Bz=Ay

_M = Matrix((
    (1,  0,  0,  0),
    (0,  0, -1,  0),
    (0,  1,  0,  0),
    (0,  0,  0,  1),
))

def _arkit_to_blender_matrix(vals):
    """
    Build a 4x4 Blender matrix_world from ARKit data.
    vals: 12 floats = [c0x,c0y,c0z, c1x,c1y,c1z, c2x,c2y,c2z, px,py,pz]
    """
    T_arkit = Matrix((
        (vals[0], vals[3], vals[6], vals[9]),
        (vals[1], vals[4], vals[7], vals[10]),
        (vals[2], vals[5], vals[8], vals[11]),
        (0,       0,       0,       1),
    ))
    return _M @ T_arkit


# =====================================================
# Globals
# =====================================================
_BM_MAGIC = b'BM'     # 2-byte packet header — rejects non-BlendMotion UDP traffic
_BM_DEBUG = False      # Set True to enable verbose console logging

_server = None
_last_frame = None
_ref_converted = None
_ref_cam_matrix = None
_smoothed_matrix = None
_is_recording = False
_pos_calibrated = False
_use_local = False  # True when camera has a parent (empty, path, etc.)
_smoothed_delta = None  # Extra smoothing for phone input when parented
_ref_loc = None       # Captured cam.location at calibration (avoids matrix round-trip)
_ref_rot_quat = None  # Captured cam rotation as quaternion at calibration
_record_fps = 24
_rec_start_time = None
_rec_frame_count = 0


# =====================================================
# UDP Protocol (v1.1)
# =====================================================
# All packets are prefixed with 2-byte magic: b'BM' (0x42, 0x4D)
# Packets without this prefix are silently discarded.
#
# Binary frame packet (51 bytes, little-endian):
#   Bytes  0-1:  b'BM' magic header
#   Bytes  2-49: 12x float32 = 3x3 rotation + 3D position
#                [c0x,c0y,c0z, c1x,c1y,c1z, c2x,c2y,c2z, px,py,pz]
#                Column-major ARKit camera transform (right-handed)
#   Byte   50:   uint8 recording flag (0=off, 1=on)
#
# Text commands (UTF-8, max 128 bytes):
#   BM:RCAL\n     — Recalibrate position + rotation
#   BM:TREC\n     — Toggle recording on/off
#   BM:SENS:%.2f  — Set sensitivity (0.1–3.0)
#   BM:PSCL:%.2f  — Set position scale (0.1–50.0)
#   BM:RFPS:%d    — Set record FPS (24, 25, 30, or 60)
#
# Validation rules:
#   - Magic header required on all packets
#   - Float values: reject NaN, Inf, and |value| > 1000
#   - Text commands: max 128 bytes, values range-checked
#   - Unknown packets: silently discarded
# =====================================================

# =====================================================
# UDP Receiver
# =====================================================
class UDPReceiver:
    def __init__(self, port=9090):
        self.port = port
        self.running = False
        self.connected = False
        self.client_ip = ""
        self.queue = Queue(maxsize=120)  # ~2 seconds of frames at 60fps
        self._sock = None
        self._thread = None

    def start(self):
        if self.running:
            return True
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self._sock.bind(("0.0.0.0", self.port))
        except OSError as e:
            print(f"[BlendMotion] Port {self.port} error: {e}")
            return False
        self._sock.settimeout(1.0)
        self.running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        print(f"[BlendMotion] Listening on UDP port {self.port}")
        return True

    def stop(self):
        self.running = False
        self.connected = False
        if self._sock:
            try:
                self._sock.close()
            except Exception:
                pass
            self._sock = None
        # Wait for thread to finish before returning — prevents crash on Blender exit
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        self._thread = None

    def _safe_put(self, item):
        """Non-blocking put — drops packet if queue full."""
        try:
            self.queue.put_nowait(item)
        except Full:
            pass  # Drop oldest-style: queue full = skip this packet

    def _loop(self):
        last_time = 0
        while self.running:
            try:
                data, addr = self._sock.recvfrom(256)

                # Reject packets without BM magic header
                if len(data) < 2 or data[:2] != _BM_MAGIC:
                    continue

                self.connected = True
                self.client_ip = addr[0]
                last_time = time.time()

                if len(data) == 51:
                    # Binary frame: BM(2) + 12 floats(48) + rec(1) = 51 bytes
                    vals = struct.unpack('<12f', data[2:50])
                    rec = data[50]
                    # Validate: reject NaN/Inf values (corrupt or malicious packets)
                    if any(math.isnan(v) or math.isinf(v) for v in vals):
                        continue
                    # Validate: reasonable transform range (100m should be enough)
                    if any(abs(v) > 1000.0 for v in vals):
                        continue
                    # Validate: rec byte must be 0 or 1
                    if rec > 1:
                        continue
                    self._safe_put({'vals': vals, 'rec': rec})
                elif len(data) <= 130:
                    # Text commands: BM: prefix + command
                    # Strip BM: prefix (3 bytes) to get raw command text
                    try:
                        text = data[3:].decode('utf-8').strip()
                        for line in text.split('\n'):
                            line = line.strip()
                            if line == 'RCAL':
                                self._safe_put({'cmd': 'rcal'})
                                if _BM_DEBUG:
                                    print("[BlendMotion] RCAL command received")
                            elif line == 'TREC':
                                self._safe_put({'cmd': 'trec'})
                            elif line.startswith('SENS:'):
                                val = float(line[5:])
                                if 0.1 <= val <= 3.0:
                                    self._safe_put({'cmd': 'sens', 'val': val})
                            elif line.startswith('PSCL:'):
                                val = float(line[5:])
                                if 0.1 <= val <= 50.0:
                                    self._safe_put({'cmd': 'pscl', 'val': val})
                            elif line.startswith('RFPS:'):
                                val = int(line[5:])
                                if val in (24, 25, 30, 60):
                                    self._safe_put({'cmd': 'rfps', 'val': val})
                    except (ValueError, UnicodeDecodeError):
                        pass

            except socket.timeout:
                if self.connected and (time.time() - last_time > 3):
                    self.connected = False
                    self.client_ip = ""
                continue
            except OSError:
                break


# =====================================================
# Matrix Smoothing
# =====================================================
def _lerp_matrix(a, b, t):
    """Interpolate between two 4x4 matrices."""
    a_loc, a_rot, _ = a.decompose()
    b_loc, b_rot, _ = b.decompose()
    loc = a_loc.lerp(b_loc, t)
    rot = a_rot.slerp(b_rot, t)
    mat = rot.to_matrix().to_4x4()
    mat.translation = loc
    return mat


# =====================================================
# Timer
# =====================================================
def _timer():
    global _server, _last_frame
    global _ref_converted, _ref_cam_matrix
    global _smoothed_matrix, _is_recording, _pos_calibrated, _use_local, _smoothed_delta
    global _ref_loc, _ref_rot_quat
    global _record_fps, _rec_start_time, _rec_frame_count

    if _server is None or not _server.running:
        return None

    # Don't interfere with Blender's animation playback — modifying
    # camera transforms while the depsgraph is rebuilding for a new
    # frame causes EXCEPTION_ACCESS_VIOLATION in deg_eval_copy_is_expanded.
    try:
        if bpy.context.screen and bpy.context.screen.is_animation_playing:
            return 0.016
    except Exception:
        pass

    scene = bpy.context.scene
    cam = scene.camera
    if cam is None:
        return 0.016

    latest = None
    do_trec = False
    do_rcal = False

    try:
        while True:
            msg = _server.queue.get_nowait()
            if 'cmd' in msg:
                if msg['cmd'] == 'trec':
                    do_trec = True
                elif msg['cmd'] == 'rcal':
                    do_rcal = True
                elif msg['cmd'] == 'sens':
                    scene.bm_sensitivity = msg['val']
                elif msg['cmd'] == 'pscl':
                    scene.bm_pos_scale = msg['val']
                elif msg['cmd'] == 'rfps':
                    _record_fps = max(1, min(120, msg['val']))
                    scene.render.fps = _record_fps
                    if _BM_DEBUG:
                        print(f"[BlendMotion] Record FPS set to {_record_fps} (scene FPS synced)")
            else:
                latest = msg
    except Empty:
        pass

    if latest is not None:
        _last_frame = latest

    # Remote recalibrate from iPhone (RCAL command)
    if do_rcal:
        rcal_frame = _last_frame if _last_frame is not None else latest
        if rcal_frame is not None and cam is not None:
            _ref_converted = _arkit_to_blender_matrix(rcal_frame['vals'])
            _use_local = cam.parent is not None
            if _use_local:
                _ref_cam_matrix = cam.matrix_basis.copy()
                # Capture raw channel values — avoids matrix decompose round-trip
                # which causes position snap with Keep Transform parenting
                _ref_loc = cam.location.copy()
                _ref_rot_quat = cam.rotation_quaternion.copy() if cam.rotation_mode == 'QUATERNION' else cam.rotation_euler.to_quaternion()
            else:
                _ref_cam_matrix = cam.matrix_world.copy()
            _smoothed_matrix = None
            _smoothed_delta = None
            # Only enable position tracking in Full 6DoF mode
            _pos_calibrated = (scene.bm_tracking_mode == 'FULL')
            mode = "local (parented)" if _use_local else "world"
            pos_str = "position ON" if _pos_calibrated else "rotation only (locked)"
            if _BM_DEBUG:
                print(f"[BlendMotion] ✓ Remote recalibrate — {mode} — {pos_str}")
            return 0.016  # Skip this tick — avoid position snap after recalibrate

    # Auto-calibrate on first data (ROTATION ONLY)
    # Position tracking stays off until manual Recalibrate
    if _ref_converted is None and latest is not None:
        _ref_converted = _arkit_to_blender_matrix(latest['vals'])
        _use_local = cam.parent is not None
        if _use_local:
            _ref_cam_matrix = cam.matrix_basis.copy()
            _ref_loc = cam.location.copy()
            _ref_rot_quat = cam.rotation_quaternion.copy() if cam.rotation_mode == 'QUATERNION' else cam.rotation_euler.to_quaternion()
        else:
            _ref_cam_matrix = cam.matrix_world.copy()
        _pos_calibrated = False
        _smoothed_delta = None
        mode = "local (parented)" if _use_local else "world"
        if _BM_DEBUG:
            print(f"[BlendMotion] Auto-calibrated rotation ({mode}). Press Recalibrate for position.")
        return 0.016  # Skip this tick — avoid initial position snap from decompose round-trip

    # Apply tracking
    if latest is not None and _ref_converted is not None:
        smooth = scene.bm_smoothing
        pos_scale = scene.bm_pos_scale
        sens = scene.bm_sensitivity

        cur_converted = _arkit_to_blender_matrix(latest['vals'])

        # ============================================
        # KEY FORMULA (camera-angle-independent):
        #   cam.matrix_world = ref_cam @ ref_arkit⁻¹ @ cur_arkit
        # ============================================
        ref_inv = _ref_converted.inverted()
        local_delta = ref_inv @ cur_converted

        # Decompose delta for sensitivity/scale/position control
        d_loc, d_rot, d_sca = local_delta.decompose()

        # Apply sensitivity to rotation
        if sens != 1.0:
            axis, angle = d_rot.to_axis_angle()
            d_rot = Quaternion(axis, angle * sens)

        # Rebuild delta matrix
        local_delta = d_rot.to_matrix().to_4x4()

        # Only apply position if manually calibrated
        if _pos_calibrated:
            local_delta.translation = d_loc * pos_scale
        # else: translation stays zero, camera position doesn't move

        # ── Dolly Smoothing (parented mode only) ──
        # Smooths the phone input BEFORE combining with parent,
        # so parent animation stays crisp while hand-shake is dampened.
        if _use_local and scene.bm_dolly_smooth > 0.0:
            if _smoothed_delta is None:
                _smoothed_delta = local_delta.copy()
            else:
                dt = 1.0 - scene.bm_dolly_smooth
                _smoothed_delta = _lerp_matrix(_smoothed_delta, local_delta, dt)
            local_delta = _smoothed_delta

        target_matrix = _ref_cam_matrix @ local_delta

        # Smoothing
        if _smoothed_matrix is None:
            _smoothed_matrix = target_matrix.copy()
        else:
            t = 1.0 - smooth
            _smoothed_matrix = _lerp_matrix(_smoothed_matrix, target_matrix, t)

        # Apply to camera (parent-aware)
        if _use_local:
            # Differential channel approach: extract the DELTA between reference
            # and smoothed target, then apply that delta to the captured raw channel
            # values. This avoids the full matrix→euler decomposition round-trip
            # which causes position snap with Keep Transform parenting.
            diff = _ref_cam_matrix.inverted() @ _smoothed_matrix
            d_loc, d_rot, _ = diff.decompose()
            # location = ref + ref_rotation * delta_translation
            cam.location = _ref_loc + (_ref_rot_quat.to_matrix() @ d_loc)
            # rotation = ref_rotation * delta_rotation
            new_rot = _ref_rot_quat @ d_rot
            if cam.rotation_mode == 'QUATERNION':
                cam.rotation_quaternion = new_rot
            else:
                cam.rotation_euler = new_rot.to_euler(cam.rotation_mode, cam.rotation_euler)
        else:
            cam.matrix_world = _smoothed_matrix

        # Recording flag from binary packet
        if latest.get('rec', 0) == 1 and not _is_recording:
            _is_recording = True
            _rec_start_time = time.time()
            _rec_frame_count = 0
            # Select camera so keyframes are visible in timeline
            try:
                bpy.context.view_layer.objects.active = cam
                cam.select_set(True)
            except Exception:
                pass
        elif latest.get('rec', 0) == 0 and _is_recording:
            _is_recording = False

    if do_trec:
        _is_recording = not _is_recording
        if _is_recording:
            _rec_start_time = time.time()
            _rec_frame_count = 0
            # Select camera so keyframes are visible in timeline
            try:
                bpy.context.view_layer.objects.active = cam
                cam.select_set(True)
            except Exception:
                pass
        state = "ON" if _is_recording else "OFF"
        if _BM_DEBUG:
            print(f"[BlendMotion] Recording: {state} at {_record_fps} fps")

    if _is_recording and _rec_start_time is not None:
        elapsed = time.time() - _rec_start_time
        expected_frame = int(elapsed * _record_fps)
        if expected_frame > _rec_frame_count:
            f = scene.frame_current
            cam.keyframe_insert("location", frame=f)
            # Keyframe the rotation channel matching the camera's rotation mode
            if cam.rotation_mode == 'QUATERNION':
                cam.keyframe_insert("rotation_quaternion", frame=f)
            else:
                cam.keyframe_insert("rotation_euler", frame=f)
            scene.frame_current = f + 1
            _rec_frame_count = expected_frame

    try:
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
    except Exception:
        pass

    return 0.016


# =====================================================
# Operators
# =====================================================
class BM_OT_start(bpy.types.Operator):
    bl_idname = "bm.start"
    bl_label = "Start"

    def execute(self, context):
        global _server, _last_frame
        global _ref_converted, _ref_cam_matrix, _smoothed_matrix, _pos_calibrated, _use_local, _smoothed_delta
        global _ref_loc, _ref_rot_quat
        if _server and _server.running:
            self.report({'WARNING'}, "Already running")
            return {'CANCELLED'}
        if context.scene.camera is None:
            self.report({'ERROR'}, "No camera in scene!")
            return {'CANCELLED'}

        # Force cleanup any leftover state
        if bpy.app.timers.is_registered(_timer):
            bpy.app.timers.unregister(_timer)
        if _server:
            _server.stop()

        _last_frame = None
        _ref_converted = None
        _ref_cam_matrix = None
        _smoothed_matrix = None
        _pos_calibrated = False
        _use_local = False
        _smoothed_delta = None
        _ref_loc = None
        _ref_rot_quat = None

        _server = UDPReceiver(port=context.scene.bm_port)
        if not _server.start():
            self.report({'ERROR'}, f"Port {context.scene.bm_port} in use")
            _server = None
            return {'CANCELLED'}

        bpy.app.timers.register(_timer)

        # Auto-switch viewport to camera view
        if context.scene.bm_view_through_camera:
            try:
                for area in context.screen.areas:
                    if area.type == 'VIEW_3D':
                        space = area.spaces.active
                        if hasattr(space, 'region_3d') and space.region_3d:
                            space.region_3d.view_perspective = 'CAMERA'
                        break
            except Exception:
                pass  # Non-critical — don't block tracking start

        self.report({'INFO'}, f"Listening on port {context.scene.bm_port}")
        return {'FINISHED'}


class BM_OT_stop(bpy.types.Operator):
    bl_idname = "bm.stop"
    bl_label = "Stop"

    def execute(self, context):
        global _server, _ref_converted, _smoothed_matrix, _is_recording, _pos_calibrated, _use_local, _smoothed_delta
        global _ref_loc, _ref_rot_quat
        global _rec_start_time, _rec_frame_count
        # Unregister timer first
        if bpy.app.timers.is_registered(_timer):
            bpy.app.timers.unregister(_timer)
        # Then kill server
        if _server:
            _server.stop()
            _server = None
        _ref_converted = None
        _smoothed_matrix = None
        _smoothed_delta = None
        _ref_loc = None
        _ref_rot_quat = None
        _is_recording = False
        _pos_calibrated = False
        _use_local = False
        _rec_start_time = None
        _rec_frame_count = 0
        self.report({'INFO'}, "Stopped")
        return {'FINISHED'}


class BM_OT_recalibrate(bpy.types.Operator):
    bl_idname = "bm.recalibrate"
    bl_label = "Recalibrate"
    bl_description = "Calibrate position + rotation from current pose"

    def execute(self, context):
        global _ref_converted, _ref_cam_matrix, _smoothed_matrix, _last_frame, _pos_calibrated, _use_local, _smoothed_delta
        global _ref_loc, _ref_rot_quat
        cam = context.scene.camera
        if _last_frame is not None and cam is not None:
            _ref_converted = _arkit_to_blender_matrix(_last_frame['vals'])
            _use_local = cam.parent is not None
            if _use_local:
                _ref_cam_matrix = cam.matrix_basis.copy()
                _ref_loc = cam.location.copy()
                _ref_rot_quat = cam.rotation_quaternion.copy() if cam.rotation_mode == 'QUATERNION' else cam.rotation_euler.to_quaternion()
            else:
                _ref_cam_matrix = cam.matrix_world.copy()
            _smoothed_matrix = None
            _smoothed_delta = None
            # Only enable position tracking in Full 6DoF mode
            _pos_calibrated = (context.scene.bm_tracking_mode == 'FULL')
            mode = "local (parented)" if _use_local else "world"
            pos_str = "position ON" if _pos_calibrated else "rotation only"
            self.report({'INFO'}, f"Recalibrated — {mode} — {pos_str}")
        return {'FINISHED'}


class BM_OT_feedback(bpy.types.Operator):
    bl_idname = "bm.feedback"
    bl_label = "Send Feedback"
    bl_description = "Open email to send feedback or report a bug"

    def execute(self, context):
        import webbrowser
        import platform
        from urllib.parse import quote
        blender_ver = f"{bpy.app.version[0]}.{bpy.app.version[1]}.{bpy.app.version[2]}"
        os_info = f"{platform.system()} {platform.release()}"
        subject = quote(f"BlendMotion Feedback — v{BLENDMOTION_VERSION}")
        body = quote(
            f"\n\n"
            f"— Please describe your issue above this line —\n"
            f"\n"
            f"────────────────────────\n"
            f"System Info (auto-filled)\n"
            f"────────────────────────\n"
            f"Addon: BlendMotion v{BLENDMOTION_VERSION}\n"
            f"Blender: {blender_ver}\n"
            f"OS: {os_info}\n"
            f"Python: {platform.python_version()}\n"
            f"────────────────────────"
        )
        url = f"mailto:skettchdev@gmail.com?subject={subject}&body={body}"
        webbrowser.open(url)
        self.report({'INFO'}, "Opening email client...")
        return {'FINISHED'}


class BM_OT_support(bpy.types.Operator):
    bl_idname = "bm.support"
    bl_label = "Support & FAQ"
    bl_description = "Open support page in browser"

    def execute(self, context):
        import webbrowser
        webbrowser.open("https://blendermarket.com/products/blendmotion")
        return {'FINISHED'}


class BM_OT_copy_ip(bpy.types.Operator):
    bl_idname = "bm.copy_ip"
    bl_label = "Copy IP"
    bl_description = "Copy your local IP to clipboard — paste it on your iPhone"

    def execute(self, context):
        ip = _get_local_ip()
        if ip:
            context.window_manager.clipboard = ip
            self.report({'INFO'}, f"Copied: {ip}")
        else:
            self.report({'WARNING'}, "No network found")
        return {'FINISHED'}


# =====================================================
# Preset System (dropdown with update callback)
# =====================================================

_PRESETS = {
    'HANDHELD':  {'sens': 1.0, 'smooth': 0.30, 'scale': 5.0,  'dolly': 0.0},
    'CINEMATIC': {'sens': 0.7, 'smooth': 0.60, 'scale': 5.0,  'dolly': 0.5},
    'DOLLY':     {'sens': 0.5, 'smooth': 0.50, 'scale': 10.0, 'dolly': 0.7},
    'CRANE':     {'sens': 0.4, 'smooth': 0.70, 'scale': 15.0, 'dolly': 0.8},
    'RAW':       {'sens': 1.0, 'smooth': 0.00, 'scale': 5.0,  'dolly': 0.0},
}

def _on_preset_change(self, context):
    """Callback when preset dropdown changes — applies slider values."""
    key = self.bm_preset
    p = _PRESETS.get(key)
    if p is None:
        return
    self.bm_sensitivity = p['sens']
    self.bm_smoothing = p['smooth']
    self.bm_pos_scale = p['scale']
    self.bm_dolly_smooth = p['dolly']


# =====================================================
# Post FX Operators
# =====================================================

class BM_OT_smooth_keyframes(bpy.types.Operator):
    bl_idname = "bm.smooth_keyframes"
    bl_label = "Smooth Keyframes"
    bl_description = "Apply additional smoothing to existing camera keyframes (1-2-1 kernel)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        cam = context.scene.camera
        if cam is None:
            return False
        fcurves, _ = _get_cam_fcurves(cam)
        return fcurves is not None

    def execute(self, context):
        cam = context.scene.camera
        iters = context.scene.bm_smooth_iters
        fcurves, _ = _get_cam_fcurves(cam)
        if fcurves is None:
            self.report({'WARNING'}, "No animation data found")
            return {'CANCELLED'}

        # ── Location: 1-2-1 kernel (safe for linear values) ──
        loc_count = 0
        for fc in fcurves:
            if fc.data_path != "location":
                continue
            pts = fc.keyframe_points
            if len(pts) < 3:
                continue
            for _ in range(iters):
                vals = [p.co[1] for p in pts]
                for i in range(1, len(vals) - 1):
                    pts[i].co[1] = vals[i - 1] * 0.25 + vals[i] * 0.5 + vals[i + 1] * 0.25
            fc.update()
            loc_count += 1

        # ── Rotation: quaternion-space nlerp smoothing ──────────
        # Why: Euler angles wrap at ±180° causing the 1-2-1 kernel
        # to average across the discontinuity → camera snaps/flips.
        # Solution: convert to quaternions, ensure consistent hemisphere,
        # smooth with weighted nlerp, convert back.
        is_quat = cam.rotation_mode == 'QUATERNION'
        rot_path = "rotation_quaternion" if is_quat else "rotation_euler"
        n_comp = 4 if is_quat else 3

        rot_fcs = sorted(
            [fc for fc in fcurves if fc.data_path == rot_path],
            key=lambda fc: fc.array_index
        )

        rot_count = 0
        if len(rot_fcs) == n_comp:
            n_keys = min(len(fc.keyframe_points) for fc in rot_fcs)
            if n_keys >= 3:
                for _ in range(iters):
                    # 1) Read all keyframes as quaternions
                    quats = []
                    for i in range(n_keys):
                        vals = [rot_fcs[j].keyframe_points[i].co[1]
                                for j in range(n_comp)]
                        if is_quat:
                            q = Quaternion(vals)
                        else:
                            q = Euler(vals, cam.rotation_mode).to_quaternion()
                        quats.append(q)

                    # 2) Ensure consistent hemisphere (shortest path)
                    #    q and -q represent the same rotation; pick the
                    #    sign that keeps dot product positive vs neighbour
                    for i in range(1, len(quats)):
                        if quats[i].dot(quats[i - 1]) < 0:
                            quats[i].negate()

                    # 3) 1-2-1 weighted nlerp — preserves first & last
                    new_quats = [quats[0]]
                    for i in range(1, len(quats) - 1):
                        q = Quaternion([
                            quats[i - 1][c] * 0.25
                            + quats[i][c] * 0.5
                            + quats[i + 1][c] * 0.25
                            for c in range(4)
                        ])
                        q.normalize()
                        new_quats.append(q)
                    new_quats.append(quats[-1])
                    quats = new_quats

                # 4) Write back to fcurves
                if is_quat:
                    for i in range(n_keys):
                        for j in range(4):
                            rot_fcs[j].keyframe_points[i].co[1] = quats[i][j]
                else:
                    # Convert quaternions back to euler with compat chain
                    # to avoid introducing new discontinuities
                    ref_e = Euler(
                        [rot_fcs[j].keyframe_points[0].co[1]
                         for j in range(n_comp)],
                        cam.rotation_mode
                    )
                    for i in range(n_keys):
                        e = quats[i].to_euler(cam.rotation_mode, ref_e)
                        for j in range(n_comp):
                            rot_fcs[j].keyframe_points[i].co[1] = e[j]
                        ref_e = e  # chain: next frame uses this as reference

                for fc in rot_fcs:
                    fc.update()
                rot_count = len(rot_fcs)

        total = loc_count + rot_count
        self.report({'INFO'}, f"Smoothed {total} channels × {iters} iterations")
        return {'FINISHED'}


class BM_OT_bake_to_world(bpy.types.Operator):
    bl_idname = "bm.bake_to_world"
    bl_label = "Bake to World"
    bl_description = "Bake parented camera animation to world space and remove parent"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        cam = context.scene.camera
        if cam is None or cam.parent is None:
            return False
        fcurves, _ = _get_cam_fcurves(cam)
        return fcurves is not None

    def execute(self, context):
        scene = context.scene
        cam = scene.camera
        depsgraph = context.evaluated_depsgraph_get()
        fcurves, _ = _get_cam_fcurves(cam)
        if fcurves is None:
            self.report({'WARNING'}, "No animation data found")
            return {'CANCELLED'}

        # 1. Collect all unique keyframe frames from the camera
        frames = set()
        for fc in fcurves:
            if fc.data_path in ("location", "rotation_euler", "rotation_quaternion"):
                for kp in fc.keyframe_points:
                    frames.add(int(round(kp.co[0])))

        if not frames:
            self.report({'WARNING'}, "No keyframes found on camera")
            return {'CANCELLED'}

        frames = sorted(frames)
        original_frame = scene.frame_current

        # 2. Capture world-space matrix at every keyframe
        world_matrices = {}
        for f in frames:
            scene.frame_set(f)
            depsgraph.update()
            world_matrices[f] = cam.matrix_world.copy()

        # 3. Remove old keyframes (re-fetch fcurves — safe iteration)
        fcurves2, _ = _get_cam_fcurves(cam)
        paths_to_clear = ["location", "rotation_euler", "rotation_quaternion"]
        for fc in list(fcurves2):
            if fc.data_path in paths_to_clear:
                fcurves2.remove(fc)

        # 4. Clear parent
        cam.parent = None
        cam.matrix_parent_inverse = Matrix.Identity(4)

        # 5. Write world-space keyframes
        for f in frames:
            scene.frame_set(f)
            loc, rot, _ = world_matrices[f].decompose()
            cam.location = loc
            if cam.rotation_mode == 'QUATERNION':
                cam.rotation_quaternion = rot
            else:
                cam.rotation_euler = rot.to_euler(cam.rotation_mode)

            cam.keyframe_insert("location", frame=f)
            if cam.rotation_mode == 'QUATERNION':
                cam.keyframe_insert("rotation_quaternion", frame=f)
            else:
                cam.keyframe_insert("rotation_euler", frame=f)

        scene.frame_set(original_frame)
        self.report({'INFO'}, f"Baked {len(frames)} frames to world space — parent removed")
        return {'FINISHED'}


# =====================================================
# Helpers
# =====================================================

def _get_cam_fcurves(cam):
    """Get fcurves collection for camera — compatible with Blender 4.x and 5.0+.
    Returns (fcurves_collection, is_channelbag) or (None, False)."""
    if cam.animation_data is None or cam.animation_data.action is None:
        return None, False
    action = cam.animation_data.action
    # Blender 5.0+: layered actions — fcurves live in channelbag
    if hasattr(cam.animation_data, 'action_slot'):
        try:
            from bpy_extras import anim_utils
            slot = cam.animation_data.action_slot
            if slot is None:
                return None, False
            # Try both API names (get = 4.4+, ensure = 5.0+)
            get_fn = getattr(anim_utils, 'action_get_channelbag_for_slot',
                     getattr(anim_utils, 'action_ensure_channelbag_for_slot', None))
            if get_fn is not None:
                channelbag = get_fn(action, slot)
                if channelbag is not None:
                    return channelbag.fcurves, True
        except (ImportError, AttributeError, TypeError):
            pass
    # Blender 4.x: legacy action.fcurves
    if hasattr(action, 'fcurves'):
        return action.fcurves, False
    return None, False
def _get_local_ip():
    """Get this PC's local network IP address."""
    import socket
    try:
        # Connect to external address to find local IP (doesn't actually send data)
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return None


def _is_port_available(port):
    """Check if UDP port is available."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(("", port))
        s.close()
        return True
    except OSError:
        return False


# =====================================================
# Panel
# =====================================================
class BM_PT_panel(bpy.types.Panel):
    bl_label = "BlendMotion"
    bl_idname = "BM_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BlendMotion"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        cam = scene.camera

        # Header with version
        row = layout.row()
        row.label(text=f"v{BLENDMOTION_VERSION}", icon="INFO")
        row.label(text="by Skettch")

        layout.separator()

        if _server and _server.running:
            layout.operator("bm.stop", text="Stop", icon="PAUSE")
            box = layout.box()
            if _server.connected:
                box.label(text=f"Connected: {_server.client_ip}", icon="CHECKMARK")
            else:
                box.label(text=f"Port {scene.bm_port} — waiting...", icon="TIME")
            if _ref_converted is not None:
                if _pos_calibrated:
                    mode = "Local (parented)" if _use_local else "World"
                    box.label(text=f"Rot + Pos ✓ [{mode}]", icon="CHECKMARK")
                elif scene.bm_tracking_mode == 'ROT_ONLY':
                    box.label(text="Rotation Only mode ✓", icon="ORIENTATION_GIMBAL")
                else:
                    box.label(text="Rotation only — Recalibrate for position", icon="ORIENTATION_GIMBAL")
                if _use_local and cam and cam.parent:
                    box.label(text=f"Parent: {cam.parent.name}", icon="LINKED")
            if _is_recording:
                box.label(text=f"⬤ RECORDING @ {_record_fps} fps", icon="REC")
            layout.separator()
            layout.operator("bm.recalibrate", icon="PIVOT_CURSOR")
        else:
            # ── Preflight Checklist ──
            box = layout.box()
            box.label(text="Preflight Checklist", icon="CHECKMARK")

            # 1. Local IP
            local_ip = _get_local_ip()
            if local_ip:
                row = box.row()
                row.label(text=f"Your IP: {local_ip}", icon="CHECKMARK")
                row.operator("bm.copy_ip", text="", icon="COPYDOWN")
            else:
                box.label(text="No network — connect to WiFi", icon="ERROR")

            # 2. Camera check
            if cam:
                box.label(text=f"Camera: {cam.name} ✓", icon="CHECKMARK")
            else:
                box.label(text="No active camera!", icon="ERROR")

            # 3. Port check
            port = scene.bm_port
            if _is_port_available(port):
                box.label(text=f"Port {port}: Available ✓", icon="CHECKMARK")
            else:
                box.label(text=f"Port {port}: In use — change port!", icon="ERROR")

            # 4. Scene FPS
            box.label(text=f"Scene FPS: {scene.render.fps}", icon="CHECKMARK")

            # 5. Reminders
            box.separator()
            box.label(text="iPhone: Same WiFi + Landscape", icon="INFO")

            layout.separator()
            layout.prop(scene, "bm_port")
            layout.prop(scene, "bm_tracking_mode")
            layout.prop(scene, "bm_view_through_camera")
            layout.operator("bm.start", text="Start", icon="PLAY")

        layout.separator()
        layout.prop(scene, "bm_sensitivity", slider=True)
        layout.prop(scene, "bm_smoothing", slider=True)

        # Position Scale — hidden in Rotation Only mode (irrelevant)
        if scene.bm_tracking_mode == 'FULL':
            layout.prop(scene, "bm_pos_scale", slider=True)

        # Dolly Smooth — only visible when camera has a parent
        if cam and cam.parent:
            layout.prop(scene, "bm_dolly_smooth", slider=True)

        # Presets dropdown
        layout.prop(scene, "bm_preset")

        # ── Post FX — only when not tracking ──
        if not (_server and _server.running):
            fcurves_check, _ = _get_cam_fcurves(cam) if cam else (None, False)
            has_keyframes = fcurves_check is not None and len(fcurves_check) > 0
            layout.separator()
            box = layout.box()
            box.label(text="Post FX", icon="SHADERFX")
            if has_keyframes:
                row = box.row(align=True)
                row.prop(scene, "bm_smooth_iters", text="Passes")
                row.operator("bm.smooth_keyframes", text="Smooth", icon="MOD_SMOOTH")
                if cam and cam.parent:
                    box.operator("bm.bake_to_world", text="Bake to World", icon="WORLD")
            else:
                box.label(text="No keyframes — record first", icon="INFO")

        layout.separator()
        row = layout.row(align=True)
        row.operator("bm.feedback", text="Feedback", icon="GREASEPENCIL")
        row.operator("bm.support", text="Support", icon="URL")


# =====================================================
# Register
# =====================================================
classes = (BM_OT_start, BM_OT_stop, BM_OT_recalibrate, BM_OT_feedback, BM_OT_support, BM_OT_copy_ip,
           BM_OT_smooth_keyframes, BM_OT_bake_to_world, BM_PT_panel)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.bm_port = bpy.props.IntProperty(
        name="Port", default=9090, min=1024, max=65535)
    bpy.types.Scene.bm_tracking_mode = bpy.props.EnumProperty(
        name="Tracking",
        items=[
            ('FULL',     "Full (6DoF)",    "Full 6DoF tracking — rotation + position. Recalibrate enables position"),
            ('ROT_ONLY', "Rotation Only",  "Rotation tracking only — position stays locked, even after Recalibrate"),
        ],
        default='FULL',
        description="Choose how BlendMotion tracks your camera",
    )
    bpy.types.Scene.bm_preset = bpy.props.EnumProperty(
        name="Preset",
        items=[
            ('HANDHELD',  "Handheld",  "Natural hand-held — 1:1 tracking, light smoothing"),
            ('CINEMATIC', "Cinematic", "Smooth cinematic — reduced sensitivity, heavy smoothing"),
            ('DOLLY',     "Dolly",     "Dolly/slider — slow, wide movement, high scale"),
            ('CRANE',     "Crane",     "Crane/jib — very smooth, large scale, high dolly smooth"),
            ('RAW',       "Raw",       "Direct tracking — no smoothing, 1:1 everything"),
        ],
        default='HANDHELD',
        update=_on_preset_change,
        description="Load preset values for Sensitivity, Smoothing, Position Scale and Dolly Smooth",
    )
    bpy.types.Scene.bm_sensitivity = bpy.props.FloatProperty(
        name="Sensitivity", default=1.0, min=0.1, max=3.0, step=10)
    bpy.types.Scene.bm_smoothing = bpy.props.FloatProperty(
        name="Smoothing", default=0.3, min=0.0, max=0.95, step=5)
    bpy.types.Scene.bm_pos_scale = bpy.props.FloatProperty(
        name="Position Scale", default=5.0, min=0.1, max=50.0, step=10)
    bpy.types.Scene.bm_dolly_smooth = bpy.props.FloatProperty(
        name="Dolly Smooth", default=0.6, min=0.0, max=0.95, step=5,
        description="Extra smoothing for phone input when camera is parented (dolly/crane mode)")
    bpy.types.Scene.bm_smooth_iters = bpy.props.IntProperty(
        name="Smooth Passes", default=5, min=1, max=50,
        description="Number of smoothing passes to apply to keyframes")
    bpy.types.Scene.bm_view_through_camera = bpy.props.BoolProperty(
        name="View Through Camera", default=True,
        description="Auto-switch viewport to camera view when tracking starts")
    print(f"[BlendMotion] v{BLENDMOTION_VERSION} by Skettch — registered")

def unregister():
    global _server, _ref_converted, _smoothed_matrix, _pos_calibrated, _use_local, _smoothed_delta
    global _ref_loc, _ref_rot_quat
    if bpy.app.timers.is_registered(_timer):
        bpy.app.timers.unregister(_timer)
    if _server:
        _server.stop()
        _server = None
    _ref_converted = None
    _smoothed_matrix = None
    _smoothed_delta = None
    _ref_loc = None
    _ref_rot_quat = None
    _pos_calibrated = False
    _use_local = False
    for prop in ("bm_port", "bm_tracking_mode", "bm_preset", "bm_sensitivity", "bm_smoothing", "bm_pos_scale", "bm_dolly_smooth", "bm_smooth_iters", "bm_view_through_camera"):
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
